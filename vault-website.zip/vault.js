// vault.js - Shared by ALL Vault pages. Don't copy Firebase config again.
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

export const firebaseConfig = {apiKey:"AIzaSyAIb460Ypo4sCXzEEQvZTdRz0SbwjgDXX0",authDomain:"vault-21e60.firebaseapp.com",projectId:"vault-21e60",storageBucket:"vault-21e60.firebasestorage.app",messagingSenderId:"455586846273",appId:"1:455586846273:web:3bb62f9727c36ac68098c0",measurementId:"G-3FVDVN4F3V"};
export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const OWNER_EMAIL = "vaultboard19@gmail.com";
export const TOTAL_SUPPLY = 1000000;
export function fmt(n,code){
  if(code==='BTC') return Number(n||0).toFixed(6);
  if(code==='ETH') return Number(n||0).toFixed(4);
  return Number(n||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
}
export function showMsg(id,t,type){ const el=document.getElementById(id); if(!el) return; el.textContent=t; el.className='msg '+type; }
